export type CalendarEvent = {
  id: string;
  title: string;
  date: Date;
  description?: string;
  color?: string;
};

export type DayDetails = {
  date: Date;
  isCurrentMonth: boolean;
  isToday: boolean;
  hasEvents: boolean;
};