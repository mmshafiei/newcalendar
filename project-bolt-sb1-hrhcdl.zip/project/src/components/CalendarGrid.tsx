import React from 'react';
import { DayDetails } from '../types/calendar';

type CalendarGridProps = {
  days: DayDetails[];
  onSelectDate: (date: Date) => void;
};

export const CalendarGrid: React.FC<CalendarGridProps> = ({ days, onSelectDate }) => {
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="grid grid-cols-7 gap-1">
      {weekDays.map((day) => (
        <div
          key={day}
          className="h-10 flex items-center justify-center text-sm font-semibold text-gray-700"
        >
          {day}
        </div>
      ))}
      {days.map((day, index) => (
        <button
          key={index}
          onClick={() => onSelectDate(day.date)}
          className={`
            h-24 p-2 border border-gray-100 flex flex-col hover:bg-gray-50 transition-colors
            ${!day.isCurrentMonth ? 'text-gray-400' : 'text-gray-800'}
            ${day.isToday ? 'bg-blue-50 font-semibold' : ''}
            ${day.hasEvents ? 'relative after:absolute after:bottom-2 after:left-2 after:w-1 after:h-1 after:bg-blue-500 after:rounded-full' : ''}
          `}
        >
          <span className="text-sm">{day.date.getDate()}</span>
        </button>
      ))}
    </div>
  );
};